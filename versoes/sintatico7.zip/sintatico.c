%{
#include <stdio.h>
#include <string.h>
#include <stdlib.h>
#include <stdarg.h>
#include <stdbool.h>

#define BUFFERMAX 2000
#define MAXCHAR 100
#define VARSIZE 500
#define FUNCSIZE 1000

//Instancia variáveis
int yylex();
int yyparse();
int yyerror(const char *);
FILE *yyin;
FILE *yyout;
int COUNTER = 0;
int ERRORS  = 0;
int MAIN    = 0;
int CVARS    = 0;
int COUNTERFUNCS = 0;
int TOTALPARAMS = 1;
int FUNCCALLARGS    = 0;
int totalParams = 0;
char TEMP[MAXCHAR];

typedef enum typesList {
    INT,
    ID,
    AST
}type;

typedef struct variableTable{
    int index;
    char id[MAXCHAR];
    int declared;
    char assignedTo[MAXCHAR];
}varTable;

varTable variablesTable[VARSIZE];

    
//Struct to create function detection
typedef struct functionTable{
    int index;
    char id[MAXCHAR];
    int totalParams;
    int timesDeclared;
}funcTable;

funcTable functions[FUNCSIZE];


/*################ AST DEFINITIONS #####################*/

//Keys to pass info to createNode in the AST
typedef enum keyList{
    LPLUS,
    LMINUS,
    LMULT,
    LDIV,
    LUMINUS,
    LAND,
    LOR,
    LNOT    ,
    LGREAT,
    LGREATEQUAL      ,
    LLESSEQUAL  ,
    LLESS,
    LEQUAL,
    LDIFF      ,
    LWHILE,
    LLABELRETURN,
    LLABELFUNCCALL,
    LSTMT,
    LIF,
    LSTMTIF,
    LASSIGN,
    LENDEXPRESSION,
    LDECVAR,
    LEXP,
    LSTMTSTMT,
    LSTATEMENTFUNCCALL,
    LFUNCNARGLIST,
    LOPENPAR,
    LFUNCNNARGLIST,
    LFUNCCALL,
    LLABELCONTINUE,
    LSTMTELSE,
    LBACK,
    LCOMPASSIGN,
    LLABELBREAK,
    LASSIGNSTMT,
    LBLOCK,
    LCOMPPARAM,
    LPARAM,
    LDEF,
    LTIPAGEM
}keys;

/*################## AST STRUCTURE #################*/
typedef struct {
    int integer;
}nodeINT;
typedef struct{
    char name[MAXCHAR];
}nodeID;
typedef struct {
    int token;
    int totalkids;
    struct ASTNo **kids;
}ASTree;

typedef struct ASTNo{
    type tipo;
    union {
        nodeINT integer;
        nodeID id;
        ASTree tree;
    };
}ASTNode;
/*################## AST STRUCTURE #################*/


/*################## HELPER FUNCTIONS #################*/
//Declare functions
ASTNode *allocINT(int valor);
ASTNode *allocID(char string[MAXCHAR]);
ASTNode *allocTreeNode(int no_token, int nfilhos, ...);
void createNAryASTree(ASTNode *tree);
void createASTreeType(ASTNode *tree);

//Functions Denifitions
ASTNode *allocINT(int valor) {
    ASTNode *newnode = malloc(sizeof(ASTNode));
    newnode->tipo = INT;
    newnode->integer.integer = valor;
    return newnode;
}
ASTNode *allocID(char string[MAXCHAR]) {
    ASTNode *newnode = malloc(sizeof(ASTNode));
    newnode->tipo = ID;
    strcpy(newnode->id.name, string);
    return newnode;
}
ASTNode *allocTreeNode(int token, int totalkids, ...) {
    int i = 0;
    va_list list;

    ASTNode *newnode = malloc(sizeof(ASTNode));

    newnode->tree.kids = malloc(totalkids*sizeof(ASTNode*));
    va_start( list, totalkids);

    newnode->tipo               = AST;
    newnode->tree.token         = token;
    newnode->tree.totalkids     = totalkids;

    for(i =0; i < totalkids; i++)
         newnode->tree.kids[i] = va_arg(list, ASTNode*);

    va_end(list);
    return newnode;
}

void createNAryASTree(ASTNode *tree)
{
    if(tree != NULL) {
        if(tree->tipo == AST){
            createASTreeType(tree);
        }else if(tree->tipo == ID){
            fprintf(yyout," [%s]", tree->id.name);
        }else if(tree->tipo == INT){
            fprintf(yyout," [%d]", tree->integer.integer);
        }
    }
}

char* itoa(int val, int base){
	
	static char buf[32] = {0};
	
	int i = 30;
	
	for(; val && i ; --i, val /= base)
	
		buf[i] = "0123456789abcdef"[val % base];
	
	return &buf[i+1];
	
}

/**
 * 
 * @param token
 * @param flag ==0 (timesDeclared) flag == 1 totalParams
 * @return 
 */
int findFunction(char *token, int flag){
    
    int i = 0;
    for(i = 0; i < COUNTERFUNCS; i++){
        if(strcmp(functions[i].id, token) == 0){
            
            if(flag){
                return functions[i].totalParams;
            }else if(!flag){
                return functions[i].timesDeclared;
            }else{
                return functions[i].index;
            }
            
        }
    }
    
    return -1;
}

int findVar(char *token, int flag){
    
    int i = 0;
    for(i = 0; i < CVARS; i++){
        if(strcmp(variablesTable[i].id, token) == 0){
            
            if(flag){
                return variablesTable[i].declared;
            }else{
                return variablesTable[i].index;
            }
        }
    }

    return -1;
}

/**
 * @param ASTNode tree
 * @param item
 * @param type - 0 for BINOP ? 1 for UNOP ? 2 for 3 children
 */
void caseExpression(ASTNode *tree, char* item, int type, int label){

    if(label){
        fprintf(yyout, " [");
        fprintf(yyout, "%s", item);
    }
    //Create tree for first node
    createNAryASTree(tree->tree.kids[0]);

    //Create tree for second node if is binop operation
    if(!type)
        createNAryASTree(tree->tree.kids[1]);

    if(label)
        fprintf(yyout, "]");
}


void createASTreeType(ASTNode *tree){
    switch(tree->tree.token) {
        case LPLUS:
            caseExpression(tree, "+",0, 1);
        break;
        case LMINUS:
            caseExpression(tree, "-",0, 1);
        break;
        case LMULT:
            caseExpression(tree, "*",0, 1);
            break;
        case LDIV:
            caseExpression(tree, "/",0, 1);
            break;
        case LUMINUS:
            caseExpression(tree, "-",1, 1);
            break;
        case LAND:
            caseExpression(tree, "&&",0, 1);
            break;
        case LOR:
            caseExpression(tree, "||",0, 1);
            break;
        case LNOT:
            caseExpression(tree, "!",1, 1);
            break;
        case LGREAT:
            caseExpression(tree, ">",0, 1);
            break;
        case LGREATEQUAL:
            caseExpression(tree, ">=",0, 1);
            break;
        case LLESSEQUAL:
            caseExpression(tree, "<=",0, 1);
            break;
        case LLESS:
            caseExpression(tree, "<",0, 1);
            break;
        case LEQUAL:
            caseExpression(tree, "==",0, 1);
            break;
        case LDIFF:
            caseExpression(tree, "!=",0, 1);
            break;
        case LWHILE:
            caseExpression(tree, "while",0, 1);
            break;
        case LLABELRETURN:
            caseExpression(tree, "return",1, 1);
            break;
         case LSTMTIF:
            fprintf(yyout, " [if");
            createNAryASTree(tree->tree.kids[0]); 
            createNAryASTree(tree->tree.kids[1]);
            createNAryASTree(tree->tree.kids[2]);
            fprintf(yyout, "]"); 
            break;
        case LIF:
            caseExpression(tree, "", 0, 0);
            if(tree->tree.totalkids>2)
                createNAryASTree(tree->tree.kids[2]);
            break;
        case LSTMT:
            if(tree->tree.totalkids>=2){
                if(tree->tree.kids[0]!= NULL) {
                    caseExpression(tree, "", 0, 0);
                }else {
                    createNAryASTree(tree->tree.kids[0]);
                }
            }
            break;
        case LASSIGN:
            createNAryASTree(tree->tree.kids[0]);
            fprintf(yyout, " [assign ");
            fprintf(yyout, "[%s]", tree->tree.kids[0]->id.name);
            fprintf(yyout, "]");
            break;
        case LENDEXPRESSION:
             createNAryASTree(tree->tree.kids[0]);
             fprintf(yyout, "]");
            break;
        case LDECVAR:
                createNAryASTree(tree->tree.kids[0]);
                if(tree->tree.kids[1] != NULL)
                    createNAryASTree(tree->tree.kids[1]);
                break;
        case LEXP:
            createNAryASTree(tree->tree.kids[0]);
            break;
        case LSTMTSTMT:
            createNAryASTree(tree->tree.kids[0]);
            break;
        case LTIPAGEM:
            if( tree->tree.totalkids>=2){
                if(tree->tree.kids[1]!= NULL) {
                    fprintf(yyout, " [decvar ");
                    fprintf(yyout, "[%s]", tree->tree.kids[0]->id.name);
                    createNAryASTree(tree->tree.kids[1]);
                } else {
                    fprintf(yyout, " [decvar [%s]]", tree->tree.kids[0]->id.name);
                }
            }
            break;
        case LDEF:
                fprintf(yyout, " [decfunc [%s]",tree->tree.kids[0]->id.name);
                createNAryASTree(tree->tree.kids[1]);
                if(tree->tree.kids[1] == NULL)
                    fprintf(yyout, " [paramlist]");
                createNAryASTree(tree->tree.kids[2]);
                fprintf(yyout, "]");
                break;
        case LPARAM:
                fprintf(yyout, " [paramlist [%s]",tree->tree.kids[0]->id.name);
                createNAryASTree(tree->tree.kids[1]);
                fprintf(yyout, "]");
                break;
        case LCOMPPARAM:
                fprintf(yyout, " [%s]",tree->tree.kids[0]->id.name);
                createNAryASTree(tree->tree.kids[1]);
                break;
        case LBLOCK:
                fprintf(yyout, " [block");
                if(tree->tree.kids[0] != NULL)
                    createNAryASTree(tree->tree.kids[0]);
                if(tree->tree.kids[1] != NULL)
                        createNAryASTree(tree->tree.kids[1]);
                fprintf(yyout, "]");
                break;
         case LASSIGNSTMT:
                fprintf(yyout, " [assign ");
                createNAryASTree(tree->tree.kids[0]);
                break;
         case LCOMPASSIGN:
                fprintf(yyout, "[%s] ", tree->tree.kids[0]->id.name);
                createNAryASTree(tree->tree.kids[1]);
                fprintf(yyout, "]");
                break;
         case LBACK:
                createNAryASTree(tree->tree.kids[0]);
                 if(tree->tree.kids[1] != NULL)
                    createNAryASTree(tree->tree.kids[1]);
                break;
         case LLABELBREAK:
                fprintf(yyout, " [break]");
                break;
         case LSTMTELSE:
                createNAryASTree(tree->tree.kids[0]);
                break;
         case LLABELCONTINUE:
                fprintf(yyout," [continue]");
                break;
                
                
         case LSTATEMENTFUNCCALL:
                fprintf(yyout," [funccall ");
                createNAryASTree(tree->tree.kids[0]);
                fprintf(yyout,"]");
                break;
        
        case LLABELFUNCCALL:
            caseExpression(tree, "funccall",0, 1);
            break;
        
        case LFUNCCALL:
            if(tree->tree.kids[1] != NULL) {
                fprintf(yyout,"[%s]", tree->tree.kids[0]->id.name);
                createNAryASTree(tree->tree.kids[1]);
            }else {
                fprintf(yyout,"[%s] ", tree->tree.kids[0]->id.name);
                fprintf(yyout,"[arglist]");
            }
         break;
            
        case LFUNCNARGLIST:
                caseExpression(tree, "arglist",1, 1);
                break;
          case LOPENPAR:
            createNAryASTree(tree->tree.kids[0]);
            break;
       
        case LFUNCNNARGLIST:
            createNAryASTree( tree->tree.kids[0] );
            createNAryASTree( tree->tree.kids[1] ); 
            break;
         
    }
}

/*######## HELPER FUNCTIONS ##########*/
%}

//Define types
%union{
    ASTNode *ASTp;
    char *string;
    int intval;
};

//TERMINALS
%token <intval>DEC
%token <string>DEF
%token <string>RETURN
%token <string>LET
%token <string>IF
%token <string>ELSE
%token <string>WHILE
%token <string>ASSIGN
%token <string>CONTINUE
%token <string>BREAK
%token <string>OPENPAR
%token <string>CLOSEPAR
%token <string>OPENBLOCK
%token <string>CLOSEBLOCK
%token <string>ENDEXPRESSION
%token <string>SEPARADOR
%token <string>IDENTIFIER
%token <string>PRINTAOLA
%token <string>OR
%token <string>AND
%token <string>EQUAL
%token <string>DIFF
%token <string>LESS
%token <string>LESSEQUAL
%token <string>GREATEQUAL
%token <string>GREAT
%token <string>PLUS
%token <string>MINUS
%token <string>MULT
%token <string>DIV
%token <string>NOT

//NON TERMINALS
%type <ASTp> inicio
%type <ASTp> exp
%type <ASTp> programa
%type <ASTp> decvar
%type <ASTp> loopdecvar
%type <ASTp> decfunc
%type <ASTp> paramlist
%type <ASTp> looparams
%type <ASTp> bloco
%type <ASTp> loopstmts
%type <ASTp> assign
%type <ASTp> stmt
%type <ASTp> funccall
%type <ASTp> arglist
%type <ASTp> loopargs
%type <ASTp> loopatrib
%type <ASTp> loopexp
%type <ASTp> loopargs2

//Define Tokens that has been generated from Lexical Analyser
%left OR
%left AND
%left EQUAL DIFF
%left LESS LESSEQUAL GREATEQUAL GREAT
%left PLUS MINUS//+
%left MULT DIV//*
%left NOT
%left UMINUS

%start programa
%error-verbose
%expect 0

%%

programa    :inicio                                                    {
                                                                            //printf("1- program ");
                                                                            createNAryASTree($1);
                                                                            COUNTER++;
                                                                        }
            ;
inicio      : decvar inicio                                             {
                                                                            //printf("2 (Decvar)\n ");
                                                                            $$ = allocTreeNode(LSTMT,2,$1,$2);
                                                                            COUNTER++;
                                                                        }
            | decfunc inicio                                            {
                                                                           //printf("2 -decfunc ");
                                                                           $$ = allocTreeNode(LSTMT, 2, $1, $2);
                                                                           COUNTER++;
                                                                        }
            |                                                           {$$ = NULL;}
            ;
decvar      : LET IDENTIFIER loopatrib ENDEXPRESSION                    {
                                                                          //printf("3- let ");
                                                                          $$ = allocTreeNode(LTIPAGEM, 2, allocID($2), $3);
                                                                          
                                                                         // strcpy(variablesTable[CVARS].id, $2);
                                                                         // strcpy(variablesTable[CVARS].assignedTo, TEMP);
                                                                         // variablesTable[CVARS].index = CVARS;
                                                                         // variablesTable[CVARS].declared = 1;
                                                                          
                                                                         
                                                                          CVARS++;
                                                                          COUNTER++;
                                                                        }
            ;
loopatrib   : ASSIGN exp                                                {
                                                                            //printf("4 - let x = ");
                                                                            $$ = allocTreeNode(LENDEXPRESSION, 1, $2);
                                                                            
                                                                            COUNTER++;
                                                                        }
            |                                                           {
                                                                        //printf("4 let x;");
                                                                        $$ = NULL;
                                                                        }
            ;
decfunc     : DEF PRINTAOLA OPENPAR paramlist CLOSEPAR bloco            {
                                                                          yyerror("print ");
                                                                        }
            | DEF IDENTIFIER OPENPAR paramlist CLOSEPAR bloco           {
                                                                       // printf("6-(decfunc (%s)) \n", $2);
                                                                        $$ = allocTreeNode(LDEF,3, allocID($2), $4, $6);
                                                                        
                                                                        functions[COUNTERFUNCS].index           = COUNTERFUNCS;
                                                                        
                                                                        strcpy(functions[COUNTERFUNCS].id, $2);
                                                                        
                                                                        COUNTERFUNCS++;
                                                                        TOTALPARAMS = 1;
                                                                        
                                                                        //If function declared more than once
                                                                        if(findFunction($2, 0) == -1){
                                                                            functions[COUNTERFUNCS].timesDeclared   = 1;
                                                                        }else{
                                                                            functions[COUNTERFUNCS].timesDeclared   = functions[COUNTERFUNCS].timesDeclared + 1;
                                                                        }
                                                                        
                                                                        if(strcmp("main", $2) == 0){
                                                                            MAIN++;
                                                                        }
                                                                        
                                                                        COUNTER++;
                                                                        }
            ;
paramlist   :
             IDENTIFIER looparams                                       {
                                                                        //printf("8-(paramlist loop)\n");
                                                                        $$ = allocTreeNode(LPARAM, 2, allocID($1),$2);
                                                                        functions[COUNTERFUNCS].totalParams = TOTALPARAMS++;
                                                                        COUNTER++;
                                                                        }
            |                                                           {
                                                                        //printf("8-(no paramlist)\n");
                                                                        $$ = NULL;
                                                                        }
            ;
looparams   : SEPARADOR IDENTIFIER looparams                            {
                                                                        //printf("9-(,ID looparams) \n");
                                                                        $$ = allocTreeNode(LCOMPPARAM, 2, allocID($2),$3);
                                                                        functions[COUNTERFUNCS].totalParams = TOTALPARAMS++;
                                                                        COUNTER++;
                                                                        }
            |                                                           {$$ = NULL ;}
            ;
bloco       :OPENBLOCK loopdecvar loopstmts CLOSEBLOCK                  {
                                                                        //printf("10- [bloco] ");
                                                                        $$ = allocTreeNode(LBLOCK, 3, $2, $3);
                                                                        COUNTER++;
                                                                        }
            ;
loopdecvar  : decvar loopdecvar                                         {
                                                                        //printf("11- (loopdecvar) ");
                                                                        $$ = allocTreeNode(LDECVAR, 2, $1, $2);
                                                                        COUNTER++;
                                                                        }
            |                                                           {$$ = NULL ;}
            ;
loopstmts   : stmt loopstmts                                            {
                                                                        //printf("12- (loop stmts)\n ");
                                                                        $$ = allocTreeNode(LBACK, 2, $1, $2);
                                                                        COUNTER++;
                                                                        }
            |                                                           {$$ = NULL ;}

stmt        : funccall ENDEXPRESSION                                    {
                                                                        //printf("220- (funccall ;) \n");
                                                                        $$ = allocTreeNode(LSTATEMENTFUNCCALL, 1, $1);
                                                                        COUNTER++;
                                                                        
                                                                        }
            | assign ENDEXPRESSION                                      {
                                                                        $$ = allocTreeNode(LASSIGNSTMT, 1, $1);
                                                                        //printf("220- (assign ;)");
                                                                        COUNTER++;
                                                                        }
            | IF OPENPAR exp CLOSEPAR bloco                             {
                                                                        //printf("15- if(exp){} \n");
                                                                        $$ = allocTreeNode(LSTMTIF, 3, $3, $5);
                                                                        COUNTER++;
                                                                        }
            | IF OPENPAR exp CLOSEPAR bloco ELSE bloco                 {
                                                                        //printf("15- if(exp)else{} \n");
                                                                        $$ = allocTreeNode(LSTMTIF, 3, $3, $5, $7);
                                                                        COUNTER++;
                                                                        }
            | IF OPENPAR exp CLOSEPAR ELSE bloco                        {
                                                                        //printf("15- if(exp)else{} \n");
                                                                        $$ = allocTreeNode(LSTMTIF, 3, $3, $5, $6);
                                                                        COUNTER++;
                                                                        }
            | WHILE OPENPAR exp CLOSEPAR bloco                          {
                                                                        //printf("16- while(exp){} \n");
                                                                        $$ = allocTreeNode(LWHILE, 2, $3, $5);
                                                                        COUNTER++;
                                                                        }
            | RETURN loopexp ENDEXPRESSION                              {
                                                                        //printf("17- return loopexp; \n");
                                                                        $$ = allocTreeNode(LLABELRETURN, 1, $2);
                                                                        COUNTER++;
                                                                        }
            | BREAK ENDEXPRESSION                                       {
                                                                        //printf("20 -break; \n");
                                                                        $$ = allocTreeNode(LLABELBREAK, 2, $1, $2);
                                                                        COUNTER++;
                                                                        }
            | CONTINUE ENDEXPRESSION                                    {
                                                                        //printf("20 -continue; \n");
                                                                        $$ = allocTreeNode(LLABELCONTINUE,2,$1, $2);
                                                                        COUNTER++;
                                                                        }
            ;
loopexp: exp                                                            {
                                                                        $$ = allocTreeNode(LEXP, 1, $1);
                                                                        COUNTER++;
                                                                        }
        |                                                               {$$=NULL;}
        ;
assign      : IDENTIFIER ASSIGN exp                                     {
                                                                        //printf("23 x=exp ");
                                                                        //$$ = allocTreeNode(LASSIGNSTMT, 1, $1);
                                                                        $$ = allocTreeNode(LCOMPASSIGN, 2, allocID($1), $3);
                                                                        COUNTER++;
                                                                        }
            ;
funccall    : IDENTIFIER OPENPAR arglist CLOSEPAR                       {
                                                                       // printf("24- id() \n");
                                                                        $$ = allocTreeNode(LFUNCCALL, 2, allocID($1), $3);
                                                                        COUNTER++;
                                                                        
                                                                        totalParams = findFunction($1, 1);
                                                                        if(totalParams != FUNCCALLARGS)
                                                                            ERRORS++;
                                                                        
                                                                        FUNCCALLARGS = 0;
                                                                        }
            | PRINTAOLA OPENPAR arglist CLOSEPAR                        {
                                                                        //printf("24- id() ");
                                                                        $$ = allocTreeNode(LFUNCCALL, 2, allocID($1), $3);
                                                                        COUNTER++;
                                                                        }
            ;
arglist:
                                                                       {$$=NULL;}
        | loopargs                                                     {
                                                                        $$ = allocTreeNode(LFUNCNARGLIST, 1, $1);
                                                                        COUNTER++;
                                                                       } 
        ;  
loopargs     : exp loopargs2                                            {
                                                                        //printf("26 - [] \n");
                                                                        $$ = allocTreeNode(LFUNCNNARGLIST, 2, $1, $2);
                                                                        FUNCCALLARGS++;
                                                                        COUNTER++;
                                                                        }
            ;
loopargs2    : SEPARADOR exp loopargs2                                  {
                                                                        // printf("27 - (, [%d]) \n", $2);
                                                                         $$ = allocTreeNode(LFUNCNNARGLIST, 2, $2, $3);
                                                                        FUNCCALLARGS++;
                                                                         COUNTER++;
                                                                        }
            |                                                           {$$=NULL;}
            ;
exp         : exp PLUS exp                                              {
                                                                        //printf("28 - exp + exp ");
                                                                        $$ = allocTreeNode(LPLUS, 2, $1, $3);
                                                                        COUNTER++;
                                                                        }
            | exp MINUS exp                                             {
                                                                        //printf("29 - exp - exp ");
                                                                        $$ = allocTreeNode(LMINUS, 2, $1, $3);
                                                                        COUNTER++;
                                                                        }
            | exp MULT exp                                              {
                                                                        //printf("30 - exp * exp ");
                                                                        $$ = allocTreeNode(LMULT, 2, $1, $3);
                                                                        COUNTER++;
                                                                        }
            | exp DIV exp                                               {
                                                                        //printf("31 - exp / exp ");
                                                                        $$ = allocTreeNode(LDIV, 2, $1, $3);
                                                                        COUNTER++;
                                                                        }
            | exp LESS exp                                              {
                                                                        //printf("32 - exp < exp ");
                                                                        $$ = allocTreeNode(LLESS, 2, $1, $3);
                                                                        COUNTER++;
                                                                        }
            | exp LESSEQUAL exp                                         {
                                                                        //printf("33 - exp <= exp ");
                                                                        $$ = allocTreeNode(LLESSEQUAL, 2, $1, $3);
                                                                        COUNTER++;
                                                                        }
            | exp GREAT exp                                             {
                                                                        //printf("34 - exp > exp ");
                                                                        $$ = allocTreeNode(LGREAT, 2, $1, $3);
                                                                        COUNTER++;
                                                                        }
            | exp GREATEQUAL exp                                        {
                                                                        //printf("35 - exp >= exp ");
                                                                        $$ = allocTreeNode(LGREATEQUAL, 2, $1, $3);
                                                                        COUNTER++;
                                                                        }
            | exp EQUAL exp                                             {
                                                                        //printf("36 - exp = exp ");
                                                                        $$ = allocTreeNode(LEQUAL, 2, $1, $3);
                                                                        COUNTER++;
                                                                        }
            | exp DIFF exp                                              {
                                                                        //printf("37 - exp != exp ");
                                                                        $$ = allocTreeNode(LDIFF, 2, $1, $3);COUNTER++;
                                                                        }
            | exp AND exp                                               {
                                                                        //printf("38 - exp && exp ");
                                                                        $$ = allocTreeNode(LAND, 2, $1, $3);
                                                                        COUNTER++;
                                                                        }
            | exp OR exp                                                {
                                                                        //printf("39 - exp || exp ");
                                                                        $$ = allocTreeNode(LOR, 2, $1, $3);
                                                                        COUNTER++;
                                                                        }
            | MINUS exp %prec UMINUS                                    {
                                                                        //printf("40 - exp ");
                                                                        $$ = allocTreeNode(LUMINUS, 1, $2);
                                                                        COUNTER++;
                                                                        }
            | NOT exp                                                   {
                                                                        //printf("41 - !exp ");
                                                                        $$ = allocTreeNode(LNOT, 1, $2);
                                                                        COUNTER++;
                                                                        }
            | OPENPAR exp CLOSEPAR                                      {
                                                                        //printf("42 - (exp) ");
                                                                        $$ = allocTreeNode(LOPENPAR, 1, $2);
                                                                        COUNTER++;
                                                                        }
            | funccall                                                  {
                                                                        //printf("43 - funccall");
                                                                        $$ = allocTreeNode(LLABELFUNCCALL, 2, $1);
                                                                        COUNTER++;
                                                                        }
            | DEC                                                       {
                                                                        //printf("44 dec ");
                                                                        $$ = allocINT($1);
                                                                        
                                                                       // strcpy(TEMP, itoa($1, 10));
                                                                        
                                                                        COUNTER++;
                                                                        }
            | IDENTIFIER                                                {
                                                                        //strcpy(TEMP, $1);
                                                                        //printf("45 id  ");
                                                                        $$ = allocID($1);
                                                                        
                                                                        COUNTER++;
                                                                        }
            ;
%%

int yyerror(const char *s) {
  printf("yyerror : %s\n", s);
  ERRORS++;
  return 0;
}

int main(int argc, char** argv) {

    FILE *input  = fopen(argv[1], "r");
    FILE *output = fopen(argv[2], "w");
    int i = 0;

    yyin = input;
    yyout = output;

    fprintf(yyout,"[program");

    yyparse();
    fprintf(yyout,"]\n");

    fclose(input);
    fclose(output);
    
    //Semantic for non declared variables
    /*for(i =0; i < CVARS; i++){
        if(findVar(variablesTable[i].id, 0) != -1){
            if(findVar(variablesTable[i].assignedTo, 0) == -1){
                ERRORS++;
            }
        }
    }*/
    
    //If errors, clear file
    if(ERRORS != 0 || COUNTER==1 || (MAIN==0 || MAIN>1)){
        FILE *output = fopen(argv[2], "w");
        fclose(output);
    }
    return 0;
}
